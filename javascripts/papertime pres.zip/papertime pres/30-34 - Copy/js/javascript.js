// JavaScript Document



<!-- Example script -->
					
			$(document).ready( function() {
				
				
			
<!-- =====1st alert ===== -->	
				
$(".prompt1").click( function() {
 var rightNow = new Date();
	  
 jAlert("The Time is " + rightNow);
						                  
							
					
	
					
					
						});	
					


/*
Rough work						
	
<!-- =====2nd alert ===== -->

$(".alert_style_example1").click( function() {
	
 var rightNow = new Date();
	  
 jAlert("The Time is " + rightNow);
						            
	
	jConfirm('Can you confirm this?', 'Confirmation Dialog', function(r) {
                    jAlert('Confirmed: ' + r, 'Confirmation Results');
                });
	
	
	jAlert('Can you confirm this?', 'Confirmation Dialog', function(r) {
                    jAlert('Confirmed: ' + r, 'Confirmation Results');
                });
	
	
	
						});		
	*/					
						
<!-- =====2nd alert ===== -->
						
$(".prompt2").click( function() {
	
    var a = "Hello World";
   
	
	 var rightNow = new Date();
  
	
   
    					
						
						
		jAlert(a.indexOf("e"), 'Confirmation Dialog', function(r) {
                    jAlert(rightNow + r, 'Confirmation Results')	
						
					   });	
                	
	
	
    					
						
						
	});						
						

	
<!-- =====3 alert ===== -->
						
$(".prompt3").click( function() {
	
    var a = "Hello World";
	var b = a.slice(0 , 2);
   
	
	 var rightNow = new Date();
    
	
	// var d = rightNow.slice(0 , 2)
	 
  
    					
		jAlert( b , 'Confirmation Dialog', function(r) {
                    jAlert(rightNow + r, 'Confirmation Results' ,function(s) {
					jAlert(d + s, 'Confirmation Results')	
						
					   });	
                });	
					
						
						
	});		
		
	
	

	
	
    					
						
						
		
	
	
	
<!-- =====4 alert ===== -->
						
$(".prompt4").click( function() {
	
    var a = "Hello World";
    var rightNow = new Date();
   

	
jAlert(a.charAt("2"), 'Confirmation Dialog', function(r) {
                    jAlert(rightNow + r, 'Confirmation Results' ,function(s) {
					jAlert(rightNow.charAt("m") + s, 'Confirmation Results')	
						
					   });	
                });	
	
	
    					
						
						
	});		
	
	
	
<!-- =====5 alert ===== -->
						
$(".prompt5").click( function() {
	
    var rightNow = new Date();
    

    
    var b = 45;
    var c = b.toString();
	

 

    var dateString = rightNow.toString();
    

  
   

	
jAlert(""+rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(c , 'Confirmation Results' ,function(s) {
					jAlert(dateString + s, 'Confirmation Results')	
						
					   });	
                });	
	
	
    					
						
						
	});			
	
	
	
	
<!-- =====6 alert ===== -->
						
$(".prompt6").click( function() {
	
    var rightNow = new Date();
    

    var b = rightNow.getDay();
    
   

	
                    jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(b + r, 'Confirmation Results' )});
						
						
                });		
	
	
	
	
	
	
	
	
<!-- =====7 alert ===== -->
						
$(".prompt7").click( function() {
	var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    var rightNow = new Date();
    

    var b = rightNow.getDay();
   

    var c = 6;
    var d = 4;
   

	
                    jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(b , 'Confirmation Results' ,function(s) {
					jAlert(days[d] , 'Confirmation Results' ,function(t) {
					jAlert(days[b] , 'Confirmation Results' ,function(u) {
					jAlert(days[4] , 'Confirmation Results')	
						
					   });		
						
						
					   });		
						
					   });	
                });	
	
	
    					
						
						
	});			
	
	
	
	
	
	
<!-- =====8 alert ===== -->
						
$(".prompt8").click( function() {
	 var monthsName = ["January","Febuary","March","April","May","June","July","August","September","October",                   "November","Decmber"];

    var rightNow = new Date();
    

    var b = rightNow.getMonth();

 

    var c = 6;
    var d = 4;
   


	
                    jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(b , 'Confirmation Results' ,function(s) {
					jAlert(monthsName[d] , 'Confirmation Results' ,function(t) {
					jAlert(monthsName[b] , 'Confirmation Results' ,function(u) {
					jAlert(monthsName[4] , 'Confirmation Results')	
						
					   });		
						
						
					   });		
						
					   });	
                });	
	
	
    					
						
						
	});			
	
	
///////////////////////////////////////////////////chp32	
	
	
	<!-- =====1 alert ===== -->
	
	$(".prompt32-1").click( function() {
		
		
		var rightNow = new Date();
    

	
	var currentMonth = rightNow.getMonth();
    	
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(currentMonth  , 'Confirmation Results' )});
						
						
               
	
						
	});
	
	
	
	
	<!-- =====2 alert ===== -->
	
	$(".prompt32-2").click( function() {
		
	var rightNow = new Date();
    

	
	var currentDate = rightNow.getDate();
    	
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(currentDate  , 'Confirmation Results' )});	
		
		
	
	
						
	});	
	
	
	
	
	<!-- =====3 alert ===== -->
	
	$(".prompt32-3").click( function() {
		
		var rightNow = new Date();
    

	 var currentYear = rightNow.getFullYear();
    	
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(currentYear  , 'Confirmation Results' )});	
		
		
		
	
	
						
	});	
	
	
	
	
	<!-- =====4 alert ===== -->
	
	$(".prompt32-4").click( function() {
		
		
		var rightNow = new Date();
    

    var currentHour = rightNow.getHours();
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(currentHour  , 'Confirmation Results' )});		
		
	
	
						
	});	
	
				
<!-- =====5 alert ===== -->
	
	$(".prompt32-5").click( function() {
		
		
			var rightNow = new Date();
    

   var currentMinute = rightNow.getMinutes();
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert( currentMinute  , 'Confirmation Results' )});		
		
	
	
						
	});					
		
		
		
		
<!-- =====6 alert ===== -->
	
	$(".prompt32-6").click( function() {
		
		
			var rightNow = new Date();
    

    var currentSeconds = rightNow.getSeconds();
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert( currentSeconds  , 'Confirmation Results' )});		
		
	
	
						
	});			
		
		
<!-- =====7 alert ===== -->
	
	$(".prompt32-7").click( function() {
		
		
			var rightNow = new Date();
    

   var currentMinute = rightNow.getMilliseconds();
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert( currentMinute  , 'Confirmation Results' )});		
		
	
	
						
	});		
		
		
		
<!-- =====8 alert ===== -->
	
	$(".prompt32-8").click( function() {
		
		
			var rightNow = new Date();
    

  var currentMills = rightNow.getTime();
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert( currentMills  , 'Confirmation Results' )});		
		
	
	
						
	});			
		
		
		
		
		
		
		
	<!-- =====9 alert ===== -->
	
	$(".prompt32-9").click( function() {
		
		
			var rightNow = new Date();
    

     var currentTime = rightNow.getTime();
	
	jAlert( "" +rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(currentTime  , 'Confirmation Results' )});		
		
	
	
						
	});		
		
		
		
///////////////////////////////////////////////////////////////chp33		
		
		
<!-- =====1 alert ===== -->
	
	$(".prompt33-1").click( function() {
		
		
	var age = 2;
    var ageInDays = age * 365;
    

    var ageInHours = age * 365 * 24;
    

    //var ageInMinutes = ageInHours * 60;
    var ageInMinutes = age * 365 * 24 * 60;
  

    var ageInSeconds = age * 365 * 24 * 60 * 60;
    

    var ageInMills = age * 365 * 24 * 60 * 60 * 1000;
    
	
	
                    jAlert( ageInDays, 'Confirmation Dialog', function(r) {
                    jAlert(ageInHours , 'Confirmation Results' ,function(s) {
					jAlert(ageInMinutes , 'Confirmation Results' ,function(t) {
					jAlert(ageInSeconds , 'Confirmation Results' ,function(u) {
					jAlert(ageInMills , 'Confirmation Results')	
						
					   });		
						
						
					   });		
						
					   });	
                });	
			
		
	
	
						
	});		
		
		
		
<!-- =====2 alert ===== -->
	
	$(".prompt33-2").click( function() {
		
var today = new Date();
var milliSec = today.getTime();



var year = milliSec / (1000 * 60 * 60 * 24*365);
var year = Math.floor(year);


var days = milliSec / (1000 * 60 * 60 * 24);
var days = Math.floor(days);



var hours = milliSec / (1000 * 60 * 60 );
var hours = Math.floor(hours);


var minutes = milliSec / (1000 * 60 );
var minutes= Math.floor(minutes);



var sec = milliSec / ( 1000  );
var sec = Math.floor(sec);

    
	
	
                    jAlert(  milliSec, 'Confirmation Dialog', function(r) {
                    jAlert(year , 'Confirmation Results' ,function(s) {
					jAlert(days , 'Confirmation Results' ,function(t) {
					jAlert(hours , 'Confirmation Results' ,function(u) {
					jAlert(minutes , 'Confirmation Results',function(v) {
					jAlert(sec , 'Confirmation Results')	
						
					   });		
						
					   });		
						
						
					   });		
						
					   });	
                });	
			
		
	
	
						
	});		
			
			
			
			
			
			
	<!-- =====3 alert ===== -->
	
	$(".prompt33-3").click( function() {
		
    var rightNow = new Date();
    var a = new Date();
	 rightNow.getTime();

    var otherDay = new Date("June 11, 2017");
   

    var msDiff = otherDay.getTime() - rightNow.getTime();
   

    var diffInDays = msDiff / (1000 * 60 * 60 * 24);
	 var diffInDays = Math.floor(diffInDays);
   

    
	
	
                    jAlert(  "" + a, 'Confirmation Dialog', function(r) {
                    jAlert( "" +  otherDay , 'Confirmation Results' ,function(s) {
					jAlert(msDiff , 'Confirmation Results' ,function(t){
					jAlert(diffInDays , 'Confirmation Results' )
						
					   });	
						
					   });	
                });	
			
		
	
	
						
	});		
					
			
			
			
			
			
			
			
			
			
	<!-- =====4 alert ===== -->
	
	$(".prompt33-4").click( function() {
		
     
	   var a = new Date();
   
   var rightNow = new Date();
   
    rightNow.getTime();

    var birthdayCelebrationDate = new Date("June 11, 2017 19:00:00");
   

    var msDiff = birthdayCelebrationDate.getTime() - rightNow.getTime();
   

    var diffInDays = msDiff / (1000 * 60 * 60 * 24);
    
	 var diffInDays = Math.floor(diffInDays);
   

    
	
	
                    jAlert(  "" + a, 'Confirmation Dialog', function(r) {
                    jAlert( "" +  birthdayCelebrationDate , 'Confirmation Results' ,function(s) {
					jAlert(msDiff , 'Confirmation Results' ,function(t){
					jAlert(diffInDays , 'Confirmation Results' )
						
					   });	
						
					   });	
                });	
			
		
	
	
						
	});		
					
			
			
			
			
			
///////////////////////////////////////////////////////////////chp34					
			
			



<!-- =====1 alert ===== -->
	
	$(".prompt34-1").click( function() {
		
	var a = new Date();
	var rightNow = new Date();
    rightNow.setFullYear(2001);
	
	jAlert( "" + a, 'Confirmation Dialog', function(r) {
    jAlert( ""+rightNow  , 'Confirmation Results' )});		
		
	
	
						
	});	




<!-- =====2 alert ===== -->
	
	$(".prompt34-2").click( function() {
		
	var a = new Date();
	var rightNow = new Date();
    rightNow.setMonth(11);
	
	jAlert( "" + a, 'Confirmation Dialog', function(r) {
    jAlert( ""+rightNow  , 'Confirmation Results' )});		
		
	
	
						
	});	




<!-- =====3 alert ===== -->
	
	$(".prompt34-3").click( function() {
		
	var a = new Date();
	var rightNow = new Date();
    rightNow.setDate(15);
	
	jAlert( "" + a, 'Confirmation Dialog', function(r) {
    jAlert( ""+rightNow  , 'Confirmation Results' )});		
		
	
	
						
	});	






<!-- =====4 alert ===== -->
	
	$(".prompt34-4").click( function() {
		
	var a = new Date();
	var rightNow = new Date();
    rightNow.setHours(13);
	
	jAlert( "" + a, 'Confirmation Dialog', function(r) {
    jAlert( ""+rightNow  , 'Confirmation Results' )});		
		
	
	
						
	});	




<!-- =====5 alert ===== -->
	
	$(".prompt34-5").click( function() {
		
	var a = new Date();
	var rightNow = new Date();
    rightNow.setMinutes(05);
	
	jAlert( "" + a, 'Confirmation Dialog', function(r) {
    jAlert( ""+rightNow  , 'Confirmation Results' )});		
		
	
	
						
	});	


	<!-- =====6 alert ===== -->
	
	$(".prompt34-6").click( function() {
		
	var a = new Date();
	var rightNow = new Date();
    rightNow.setSeconds(55);
	
	jAlert( "" + a, 'Confirmation Dialog', function(r) {
    jAlert( ""+rightNow  , 'Confirmation Results' )});		
		
	
	
						
	});	
		
		<!-- =====7 alert ===== -->
	
	$(".prompt34-7").click( function() {
		
	var a = new Date();
	var rightNow = new Date();
    rightNow.setMilliseconds(867);
	
	jAlert( "" + a, 'Confirmation Dialog', function(r) {
    jAlert( ""+rightNow  , 'Confirmation Results' )});		
		
	
	
						
	});	
	
			
			
			
			
			
	/*Rough work		
			
				
											
	
<!-- =====2nd alert ===== -->
$(".prompt").click( function() {
	
	
    var rightNow = new Date();
    alert(rightNow);

    var a = "Hello World";
    alert(a.indexOf("e"));
    
    var b = 45;
    var c = b.toString();

    // Error 
    //alert(rightNow.indexOf("Feb"));	
	
		
	
	
var rightNow = new Date();
    

    var a = "Hello World";
   
    
    var b = 45;
    var c = b.toString();

    // Error 
    //alert(rightNow.indexOf("Feb"));

    var dateString = rightNow.toString();
  
    //var dateString = rightNow.toString();	
	
	
	
jAlert(""+rightNow, 'Confirmation Dialog', function(r) {
                    jAlert(a.indexOf("e") + r, 'Confirmation Results' ,function(s) {
					jAlert(dateString + s, 'Confirmation Results')	
						
					   });	
                });	
	
	
	
	
	
	
});	
	
	
	
///////////////////////////////////////////////////chp33	
						
						
						
						
										
*/});