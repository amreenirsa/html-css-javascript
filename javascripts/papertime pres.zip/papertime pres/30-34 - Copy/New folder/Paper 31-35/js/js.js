// JavaScript Document



function chp31_1(){
 var rightNow = new Date();
    alert(rightNow);

}



function chp31_2(){
 var rightNow = new Date();
    alert(rightNow);

    var a = "Hello World";
    alert(a.indexOf("e"));
    
    var b = 45;
    var c = b.toString();

    // Error 
    //alert(rightNow.indexOf("Feb"));

    var dateString = rightNow.toString();
    alert(dateString);

    //var dateString = rightNow.toString();


}



function chp31_3(){
   var rightNow = new Date();
    alert(rightNow);

    var b = rightNow.getDay();
    alert(b);



}


function chp31_4(){
   var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

    var rightNow = new Date();
    alert(rightNow);

    var b = rightNow.getDay();
    alert(b);

    var c = 6;
    var d = 4;
    alert(days[d]);
    alert(days[b]);

    alert(days[4]);




}



//=========================================chp 32
function chp32_1(){


var rightNow = new Date();
    alert(rightNow);

    var currentDay = rightNow.getDay();
    alert(currentDay);

    var currentMonth = rightNow.getMonth();
    alert(currentMonth);

    var currentDate = rightNow.getDate();
    alert(currentDate);

    var currentYear = rightNow.getFullYear();
    alert(currentYear);

    var currentHour = rightNow.getHours();
    alert(currentHour);

    var currentMinute = rightNow.getMinutes();
    alert(currentMinute);

    var currentSeconds = rightNow.getSeconds();
    alert(currentSeconds);

    var currentMills = rightNow.getMilliseconds();
    alert(currentMills);

    var currentTime = rightNow.getTime();
    alert(currentTime);



}



function chp32_2(){
 var age = 2;
    var ageInDays = age * 365;
    alert(ageInDays);

    var ageInHours = age * 365 * 24;
    alert(ageInHours);

    //var ageInMinutes = ageInHours * 60;
    var ageInMinutes = age * 365 * 24 * 60;
    alert(ageInMinutes);

    var ageInSeconds = age * 365 * 24 * 60 * 60;
    alert(ageInSeconds);

    var ageInMills = age * 365 * 24 * 60 * 60 * 1000;
    alert(ageInMills);


}
//=========================================chp 33

function chp33_1(){
 var rightNow = new Date();
    alert(rightNow);
    rightNow.getTime();

    var otherDay = new Date("June 11, 2017");
    alert(otherDay);

    var msDiff = otherDay.getTime() - rightNow.getTime();
    alert(msDiff);

    var diffInDays = msDiff / (1000 * 60 * 60 * 24);
    alert(diffInDays);


}

function chp33_2(){
var rightNow = new Date();
    alert(rightNow);
    rightNow.getTime();

    var birthdayCelebrationDate = new Date("June 11, 2017 19:00:00");
    alert(birthdayCelebrationDate);

    var msDiff = birthdayCelebrationDate.getTime() - rightNow.getTime();
    alert(msDiff);

    var diffInDays = msDiff / (1000 * 60 * 60 * 24);
    alert(diffInDays);


}



//=========================================chp 33

function chp34_1(){





 var rightNow = new Date();
    alert(rightNow);

    rightNow.setFullYear(2025);
    alert(rightNow);
    
    rightNow.setMonth(5);
    alert(rightNow);}