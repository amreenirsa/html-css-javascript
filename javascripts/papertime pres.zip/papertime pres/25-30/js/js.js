// JavaScript Document



function chp25_1(){

var text = "the quick brown fox jumps over the lazy dog";
var nextText1 = text.replace("brown","white");
var nextText2 = text.replace("hello","white");
var nextText3 = text.replace(/the/g,"not");
    
    alert(text);
    alert(nextText1);
    alert(nextText2);
	alert(nextText3);
}



//---------------------------------------------chp 26




function chp26_1(){
var a = Math.round(3.4);
    alert(a);

    var b = Math.round(3.5);
    alert(b);

    var c = Math.round(3.7);
    alert(c);

    var d = Math.round(-3.7);
    alert(d);

    var e = Math.round(-3.5);
    alert(e);

    var f = Math.round(-3.2);
    alert(f);
}


function chp26_2(){
	
var a = Math.round(0.0678437);
    alert("A : "+a);

    var b = Math.round(.2678437);
    alert("B : "+b);

    var c = Math.round(.6678437);
    alert("C : "+c);

}



function chp26_3(){


    var c = Math.ceil(3.4);
    alert("C : "+c);

    var d = Math.ceil(3.9);
    alert("D : "+d);

}



function chp26_4(){




    var c = Math.ceil(-3.4);
    alert("C : "+c);

    var d = Math.ceil(-3.9);
    alert("D : "+d);

}


function chp26_5(){


var a = Math.floor(3.4);
    alert("A : "+a);

    var b = Math.floor(3.9);
    alert("B : "+b);

  

}



function chp26_6(){


var a = Math.floor(-3.4);
    alert("A : "+a);

    var b = Math.floor(-3.9);
    alert("B : "+b);

    

}


//---------------------------------------------chp 27

function chp27_1(){


 var a = Math.random();
    alert(a);
    var b = a*10;
    var c = a*100;
    var d = a*1000;


    alert("A : "+a+" -- B : "+b);
    alert("C : "+c+" -- D : "+d);



}




function chp27_2(){
var bigDecimal = Math.random();
    var improvedNum = (bigDecimal * 6)
    var addOneInNum = improvedNum + 1;
    var numberOfStars = Math.floor(addOneInNum);

    alert(bigDecimal + " -- " +improvedNum + " -- "+ addOneInNum + " -- "+numberOfStars);


}




function chp27_3(){
var bigDecimal = Math.random();
    var improvedNum = (bigDecimal * 2)
    var addOneInNum = improvedNum + 1;
    var numberOfStars = Math.floor(addOneInNum);
if(numberOfStars == 1){
	a ="Tail"
	
	}
else if(numberOfStars == 2){
	a ="Head"
	
	}	
	
	
    alert( numberOfStars +"\n" + "Random coin value "+ a );


}


function chp27_4(){
var bigDecimal = Math.random();
    var improvedNum = (bigDecimal * 100)
    var addOneInNum = improvedNum + 1;
    var numberOfStars = Math.floor(addOneInNum);

	
	
    alert("Random number between 1 and 100 is " + numberOfStars  );


}



function chp27_5(){
	var a = prompt("please enter number between 1-10");

if(a > 10  ||  a < 1){
	b = "please enter number between 1-10"  }
	
	
else{	
    var bigDecimal = Math.random();
    var improvedNum = (bigDecimal * 10)
    var addOneInNum = improvedNum + 1;
    var numberOfStars = Math.floor(addOneInNum);
	if(a === numberOfStars){
		b = "Congratulation" + a + "is secret number";}
	else{
		b = "Try again the secret number is " +numberOfStars ;}	
}
alert( b );
}



//---------------------------------------------chp 28

function chp28_1(){
	 var a = 23;
    var b = "23";

    var c = b + 5;

    alert(c);
    
}



function chp28_2(){
	 var a = 23;
    var b = "abc";

    var c = b + 5;

    alert(c);
    
}


function chp28_3(){
var a = prompt("Enter your age");
   
    var b = a + 5;

    alert(a);
    alert(b);

}

function chp28_4(){
var currentAge = prompt("Enter your age.");
    var yearsEligibleToVote = currentAge - 18;
    var concatNumbers = currentAge + 18;

    alert(yearsEligibleToVote);
    alert(concatNumbers);}
	
	
	
	
function chp28_5(){
 var profit = "200" - "150";
   var profit1 = "200" - "duck";

    alert(profit);

    alert(profit1);
	
	}	
	
	
	
	
function chp28_6(){
 var currentAge = prompt("Enter your age.");
  var qualifyingAge = parseInt(currentAge) + 1;
  var ageStr = currentAge + 1;

  alert(currentAge);
  alert(qualifyingAge);
  alert(ageStr);
	
	}		
	
	
	
	
	
function chp28_7(){
 var num = "2.333"
  var convertedNum = parseInt(num);
  var convertedNumDecimal = parseFloat(num);
  var newVal = convertedNumDecimal + 1;

  alert(num);
  alert(convertedNum);
  alert(convertedNumDecimal);
  alert(newVal);

	
	}	
	





function chp28_8(){
 var num = "-2.333"
  var convertedNum = parseInt(num);
  var convertedNumDecimal = parseFloat(num);


  alert(num);
  alert(convertedNum);
  alert(convertedNumDecimal);
  ;

	
	}		
	
	
//---------------------------------------------chp 29




function chp29_1(){	
	var a = "34";
    alert(a);

    var b = Number(a) + 4;
    alert(b);
}
	
	
	
	
function chp29_2(){
	
	
	var num = "2.333"
  var convertedNum = Number(num);
  var convertedNumDecimal = Number(num);
  var newVal = convertedNumDecimal + 1;

  alert(num);
  alert(convertedNum);
  alert(convertedNumDecimal);
  alert(newVal);



}
	
	
	
	
function chp29_3(){
	
	
	var num = 1548
  var newVal = num + 1;
  alert(num);
  alert(newVal);

  var numString = num.toString();
  alert(numString.length);



}	
	
	//---------------------------------------------chp 30

function chp30_1(){
	var price =  9.95;
    var tax = 6.5;
    var total = price * 6.5 /100;

    alert(total);
    var fixedValue = total.toFixed(2);
    alert(fixedValue);
	
}
	
	
	function chp30_2(){
	var price =  9.95;
    var tax = 6.5;
    var num = price * 6.5 /100;

   var str = num.toString();
 if (str.charAt(str.length - 1) === "5") {
    str = str.slice(0, str.length - 1) + "6";
}
 num = Number(str);
 prettyNum = num.toFixed(2);
 alert(prettyNum)
}