# jquery.simple.thumbchanger
simple thumbnail changer
