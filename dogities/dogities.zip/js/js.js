// JavaScript Document

function f1() {

    var r = document.getElementById("input1").value;
    document.getElementById('f1').innerHTML = r;
    
}

			